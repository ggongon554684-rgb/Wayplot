using WayPlot.domain.Common;
using WayPlot.domain.Contracts;
using WayPlot.domain.Interfaces;

namespace WayPlot.Presenters;

public sealed record ShellTab(string Key, string Title, bool Enabled, string? Hint = null);

/// <summary>Decides which tabs the shell shows and which are enabled for the signed-in tenant's plan. The view only draws them.</summary>
public sealed class MainShellPresenter(LoginResult login, ITenantFeatures features)
{
    public string AppName => "WayPlot";
    public string Workspace => login.TenantName ?? "Platform";
    public string UserLine => $"{login.DisplayName} ({login.Role}) · Tier {login.Tier?.ToString() ?? "-"}";

    public IReadOnlyList<ShellTab> BuildTabs()
    {
        var tabs = new List<ShellTab>();
        if (login.Role != Roles.SuperAdmin)
        {
            tabs.AddRange(
            [
                Tab("parcel-map", "Parcel map", features.DataCollection),
                Tab("contacts", "Contacts", features.DataCollection),
                Tab("pipeline", "Pipeline", features.MainTransaction)
            ]);
            if (login.Role != Roles.Agent)
                tabs.Add(Tab("deals", "Deals & payments", features.DealsPayments));
            tabs.Add(Tab("commissions", "Commissions", features.DealsPayments));
            if (login.Role == Roles.TenantAdmin)
            {
                tabs.Add(Tab("team", "Team", features.DataCollection));
                tabs.Add(Tab("review", "Review", features.DealsPayments));
            }
        }
        tabs.Add(Tab("intelligence", "Intelligence", features.BusinessIntelligence, "Available in Tier B"));
        return tabs;
    }

    private static ShellTab Tab(string key, string title, bool enabled, string? disabledHint = null) =>
        new(key, title, enabled, enabled ? null : disabledHint ?? "Not included in your plan");
}
